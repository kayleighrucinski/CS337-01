//
//  MetricCalculator.swift
//  MetricCalc
//
//  Created by Kayleigh F. Rucinski on 9/14/21.
//

import Foundation

//calculator modes encounter
enum CalculatorModes: String {
    case temperature = "Temperature"
    case length = "Length"
    case volume = "Volume"
    case mass = "Mass"
}
//model
struct MetricCalculator {
    //declare properties (instance variables)
    //calculators current mode
    var currentMode: CalculatorModes
    //conversion constants
    let temperatureConversionMultiplier = 9.0/5.0
    let temperatureConversionOffset = 32.0;
    let lengthConversionMultiplier = 1.60934
    let volumeConversionFactor = 3.78541
    let massConversionFactor = 0.45359237
    //unit conversion method
    
    func computeMetricMeasurement(inputData: Double) -> Double {
        switch (currentMode) {
        case .temperature:
            return (inputData - temperatureConversionOffset) / temperatureConversionMultiplier
        case .length:
            return (inputData * lengthConversionMultiplier)
        case .volume:
            return (inputData * volumeConversionFactor)
        case .mass:
            return (inputData / massConversionFactor)
        }
    } //end computer metric measurement
} //end metric calculator
